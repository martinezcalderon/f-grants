/* F! Grants — Admin JS */
(function ($) {
    'use strict';

    // -------------------------------------------------------------------------
    // Bridge Generation
    // -------------------------------------------------------------------------

    $(document).on('click', '#fg-generate-bridge', function () {
        var $btn = $(this);
        var appId = $btn.data('app-id');
        var $output = $('#fg-bridge-output');

        $btn.prop('disabled', true).html('<span class="fg-spinner"></span>' + fgAdmin.strings.generating);
        $output.show().html('<em>' + fgAdmin.strings.generating + '</em>');

        $.ajax({
            url: fgAdmin.ajaxUrl,
            method: 'POST',
            data: {
                action: 'fg_generate_bridge',
                nonce: fgAdmin.nonce,
                app_id: appId,
            },
            timeout: 90000,
            success: function (res) {
                if (res.success) {
                    $output.html(res.data.draft_html);
                } else {
                    $output.html('<p style="color:#b32d2e;">' + (res.data.message || fgAdmin.strings.error) + '</p>');
                }
            },
            error: function () {
                $output.html('<p style="color:#b32d2e;">' + fgAdmin.strings.error + '</p>');
            },
            complete: function () {
                $btn.prop('disabled', false).text(
                    $btn.data('original-label') || 'Regenerate Bridge'
                );
            },
        });
    });

    // -------------------------------------------------------------------------
    // Criteria Extraction
    // -------------------------------------------------------------------------

    $(document).on('click', '#fg-extract-criteria', function () {
        var $btn = $(this);
        var oppId = $btn.data('opp-id');

        $btn.prop('disabled', true).html('<span class="fg-spinner"></span>' + fgAdmin.strings.extracting);

        $.ajax({
            url: fgAdmin.ajaxUrl,
            method: 'POST',
            data: {
                action: 'fg_extract_criteria',
                nonce: fgAdmin.nonce,
                opp_id: oppId,
            },
            timeout: 60000,
            success: function (res) {
                if (res.success) {
                    // Show confirmation then reload to render criteria display
                    alert(res.data.message);
                    window.location.reload();
                } else {
                    alert(res.data.message || fgAdmin.strings.error);
                }
            },
            error: function () {
                alert(fgAdmin.strings.error);
            },
            complete: function () {
                $btn.prop('disabled', false).text('Extract Criteria with Claude');
            },
        });
    });

    // -------------------------------------------------------------------------
    // Practice Dialogue (artist profiles)
    // -------------------------------------------------------------------------

    var dialogueHistory = [];

    $(document).on('click', '#fg-dialogue-send', function () {
        var $btn = $(this);
        var $input = $('#fg-dialogue-input');
        var $log = $('#fg-dialogue-log');
        var profileId = $btn.data('profile-id');
        var message = $input.val().trim();

        if (!message) return;

        // Append user message to log
        $log.append('<div class="fg-dialogue-msg fg-dialogue-msg--user"><strong>You:</strong> ' + escapeHtml(message) + '</div>');
        dialogueHistory.push({ role: 'user', content: message });
        $input.val('');
        $btn.prop('disabled', true);

        $.ajax({
            url: fgAdmin.ajaxUrl,
            method: 'POST',
            data: {
                action: 'fg_practice_dialogue',
                nonce: fgAdmin.nonce,
                profile_id: profileId,
                message: message,
                history: JSON.stringify(dialogueHistory),
            },
            timeout: 60000,
            success: function (res) {
                if (res.success) {
                    var reply = res.data.response;
                    $log.append('<div class="fg-dialogue-msg fg-dialogue-msg--claude"><strong>F! Grants:</strong> ' + escapeHtml(reply) + '</div>');
                    dialogueHistory.push({ role: 'assistant', content: reply });
                    $log.scrollTop($log[0].scrollHeight);
                } else {
                    alert(res.data.message || fgAdmin.strings.error);
                }
            },
            error: function () {
                alert(fgAdmin.strings.error);
            },
            complete: function () {
                $btn.prop('disabled', false);
            },
        });
    });

    // Send dialogue on Enter (not Shift+Enter)
    $(document).on('keydown', '#fg-dialogue-input', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) {
            e.preventDefault();
            $('#fg-dialogue-send').trigger('click');
        }
    });

    // -------------------------------------------------------------------------
    // Profile Sharpening
    // -------------------------------------------------------------------------

    $(document).on('click', '#fg-sharpen-profile', function () {
        var $btn = $(this);
        var profileId = $btn.data('profile-id');
        var $result = $('#fg-sharpening-result');

        $btn.prop('disabled', true).html('<span class="fg-spinner"></span> Analyzing...');
        $result.hide();

        $.ajax({
            url: fgAdmin.ajaxUrl,
            method: 'POST',
            data: {
                action: 'fg_sharpen_profile',
                nonce: fgAdmin.nonce,
                profile_id: profileId,
            },
            timeout: 60000,
            success: function (res) {
                if (res.success) {
                    var s = res.data.suggestion;
                    var html = '<div class="fg-sharpening-suggestion">'
                        + '<p><strong>Note:</strong> ' + escapeHtml(s.note || '') + '</p>';

                    if (s.signals && s.signals.length) {
                        html += '<p><strong>Signals:</strong></p><ul>';
                        $.each(s.signals, function (i, v) { html += '<li>' + escapeHtml(v) + '</li>'; });
                        html += '</ul>';
                    }

                    if (s.suggested_framing_shifts && s.suggested_framing_shifts.length) {
                        html += '<p><strong>Framing shifts:</strong></p><ul>';
                        $.each(s.suggested_framing_shifts, function (i, v) { html += '<li>' + escapeHtml(v) + '</li>'; });
                        html += '</ul>';
                    }

                    if (s.caution) {
                        html += '<p><strong>Caution:</strong> ' + escapeHtml(s.caution) + '</p>';
                    }

                    html += '</div>';
                    $result.html(html).show();
                } else {
                    alert(res.data.message || fgAdmin.strings.error);
                }
            },
            error: function () {
                alert(fgAdmin.strings.error);
            },
            complete: function () {
                $btn.prop('disabled', false).text('Analyze with Claude');
            },
        });
    });

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    function escapeHtml(str) {
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    }

})(jQuery);
