<?php
/**
 * Plugin Name: F! Grants
 * Plugin URI: https://fricking.website
 * Description: A positioning and advocacy intelligence tool for grant writers. Bridges your org's or practice's work to a specific funder's mission and values — powered by Claude AI.
 * Version: 1.0.0
 * Author: Saïd
 * Author URI: https://saidmartinezcalderon.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: f-grants
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Plugin constants
define( 'FG_VERSION',          '1.0.0' );
define( 'FG_PLUGIN_DIR',       plugin_dir_path( __FILE__ ) );
define( 'FG_PLUGIN_URL',       plugin_dir_url( __FILE__ ) );
define( 'FG_PLUGIN_BASENAME',  plugin_basename( __FILE__ ) );

// Load includes
require_once FG_PLUGIN_DIR . 'includes/class-fg-premium.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-crypto.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-logger.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-activator.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-deactivator.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-profile.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-opportunity.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-application.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-outcome.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-claude.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-admin.php';
require_once FG_PLUGIN_DIR . 'includes/class-fg-ajax.php';

// Activation / deactivation hooks
register_activation_hook( __FILE__,   array( 'FG_Activator',   'activate'   ) );
register_deactivation_hook( __FILE__, array( 'FG_Deactivator', 'deactivate' ) );

/**
 * Main plugin class — singleton.
 */
class F_Grants {

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {
        $this->init_hooks();
    }

    private function init_hooks() {
        add_action( 'plugins_loaded', array( $this, 'load_textdomain' ) );
        add_action( 'init',           array( $this, 'init' ) );
        add_action( 'admin_menu',     array( $this, 'admin_menu' ), 5 );
        add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );

        // Profile sharpening cron
        add_action( 'fg_sharpen_profiles', array( 'FG_Claude', 'cron_sharpen_profiles' ) );

        // Handle form saves before output
        FG_Admin::register_hooks();
    }

    public function load_textdomain() {
        load_plugin_textdomain( 'f-grants', false, dirname( FG_PLUGIN_BASENAME ) . '/languages' );
    }

    public function init() {
        FG_Opportunity::register_post_type();
        FG_Application::register_post_type();
        new FG_Ajax();
    }

    public function admin_menu() {
        add_menu_page(
            __( 'F Grants', 'f-grants' ),
            __( 'F Grants', 'f-grants' ),
            'manage_options',
            'f-grants',
            array( 'FG_Admin', 'render_dashboard' ),
            'dashicons-edit-page',
            3
        );

        add_submenu_page(
            'f-grants',
            __( 'Dashboard', 'f-grants' ),
            __( 'Dashboard', 'f-grants' ),
            'manage_options',
            'f-grants',
            array( 'FG_Admin', 'render_dashboard' )
        );

        add_submenu_page(
            'f-grants',
            __( 'Profiles', 'f-grants' ),
            __( 'Profiles', 'f-grants' ),
            'manage_options',
            'f-grants-profiles',
            array( 'FG_Admin', 'render_profiles_page' )
        );

        add_submenu_page(
            'f-grants',
            __( 'Opportunities', 'f-grants' ),
            __( 'Opportunities', 'f-grants' ),
            'manage_options',
            'f-grants-opportunities',
            array( 'FG_Admin', 'render_opportunities_page' )
        );

        add_submenu_page(
            'f-grants',
            __( 'Applications', 'f-grants' ),
            __( 'Applications', 'f-grants' ),
            'manage_options',
            'f-grants-applications',
            array( 'FG_Admin', 'render_applications_page' )
        );

        add_submenu_page(
            'f-grants',
            __( 'Settings', 'f-grants' ),
            __( 'Settings', 'f-grants' ),
            'manage_options',
            'f-grants-settings',
            array( 'FG_Admin', 'render_settings_page' )
        );
    }

    public function admin_scripts( $hook ) {
        if ( strpos( $hook, 'f-grants' ) === false ) {
            return;
        }

        wp_enqueue_style( 'fg-admin-css', FG_PLUGIN_URL . 'assets/css/admin.css', array(), FG_VERSION );

        wp_enqueue_script( 'fg-admin-js', FG_PLUGIN_URL . 'assets/js/admin.js', array( 'jquery' ), FG_VERSION, true );

        wp_localize_script( 'fg-admin-js', 'fgAdmin', array(
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'nonce'     => wp_create_nonce( 'fg_admin_nonce' ),
            'isPremium' => FG_Premium::is_active(),
            'strings'   => array(
                'generating'  => __( 'Generating bridge draft...', 'f-grants' ),
                'extracting'  => __( 'Extracting funder criteria...', 'f-grants' ),
                'saving'      => __( 'Saving...', 'f-grants' ),
                'error'       => __( 'Something went wrong. Please try again.', 'f-grants' ),
                'confirm_del' => __( 'Are you sure? This cannot be undone.', 'f-grants' ),
            ),
        ) );
    }
}

function f_grants() {
    return F_Grants::get_instance();
}

f_grants();
