<?php
/**
 * Fired during plugin activation.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Activator {

    const MIN_PHP = '7.4';
    const MIN_WP  = '5.8';

    public static function activate(): void {
        self::check_requirements();
        self::create_tables();
        self::set_default_options();
        self::schedule_cron();
        flush_rewrite_rules();
    }

    private static function check_requirements(): void {
        $errors = array();

        if ( version_compare( PHP_VERSION, self::MIN_PHP, '<' ) ) {
            $errors[] = sprintf(
                'F! Grants requires PHP %1$s or higher. Your server is running PHP %2$s.',
                self::MIN_PHP,
                PHP_VERSION
            );
        }

        global $wp_version;
        if ( version_compare( $wp_version, self::MIN_WP, '<' ) ) {
            $errors[] = sprintf(
                'F! Grants requires WordPress %1$s or higher. You are running WordPress %2$s.',
                self::MIN_WP,
                $wp_version
            );
        }

        if ( empty( $errors ) ) {
            return;
        }

        deactivate_plugins( FG_PLUGIN_BASENAME );

        wp_die(
            '<p><strong>' . implode( '</p><p>', array_map( 'esc_html', $errors ) ) . '</strong></p>' .
            '<p><a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">&larr; Return to Plugins</a></p>',
            'Plugin Activation Error',
            array( 'back_link' => false )
        );
    }

    private static function create_tables(): void {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Applicant Profiles — custom table, first-class persistent entity
        $profiles_table = $wpdb->prefix . 'fg_profiles';
        dbDelta( "CREATE TABLE IF NOT EXISTS $profiles_table (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            segment varchar(20) NOT NULL DEFAULT 'nonprofit',
            entity_name varchar(255) NOT NULL,
            description longtext DEFAULT NULL,
            voice_sample longtext DEFAULT NULL,
            history_log longtext DEFAULT NULL,
            created_at datetime NOT NULL,
            updated_at datetime NOT NULL,
            PRIMARY KEY (id),
            KEY segment (segment),
            KEY created_at (created_at)
        ) $charset_collate;" );
    }

    private static function set_default_options(): void {
        $defaults = array(
            'fg_claude_api_key'     => '',
            'fg_claude_model'       => 'claude-sonnet-4-6',
            'fg_debug_log_enabled'  => '0',
            'fg_profile_limit'      => 3,
        );

        foreach ( $defaults as $key => $value ) {
            if ( get_option( $key ) === false ) {
                add_option( $key, $value );
            }
        }
    }

    private static function schedule_cron(): void {
        if ( ! wp_next_scheduled( 'fg_sharpen_profiles' ) ) {
            wp_schedule_event( time(), 'weekly', 'fg_sharpen_profiles' );
        }
    }
}
