<?php
/**
 * Encryption helper for sensitive options (API keys).
 *
 * Uses AES-256-CBC via openssl with WordPress's SECURE_AUTH_KEY as the
 * secret. Falls back gracefully when openssl is unavailable.
 *
 * Mirrors FI_Crypto from F! Insights — same scheme, fg_ namespace.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Crypto {

    const CLAUDE_KEY_OPTION = 'fg_claude_api_key';
    const ENCRYPTED_PREFIX  = 'fg_enc::';
    const CIPHER            = 'AES-256-CBC';

    /**
     * Retrieve and decrypt an API key option.
     *
     * @param  string $option_name  e.g. FG_Crypto::CLAUDE_KEY_OPTION
     * @return string               Plaintext key, or '' if not set.
     */
    public static function get_key( string $option_name ): string {
        $raw = get_option( $option_name, '' );

        if ( $raw === '' ) {
            return '';
        }

        if ( strpos( $raw, self::ENCRYPTED_PREFIX ) === 0 ) {
            return self::decrypt( substr( $raw, strlen( self::ENCRYPTED_PREFIX ) ) );
        }

        // Legacy plaintext — return as-is, encrypted on next save.
        return $raw;
    }

    /**
     * Encrypt and save an API key option.
     *
     * @param string $option_name
     * @param string $plaintext
     */
    public static function save_key( string $option_name, string $plaintext ): void {
        if ( $plaintext === '' ) {
            update_option( $option_name, '' );
            return;
        }

        if ( ! self::openssl_available() ) {
            FG_Logger::warning( 'openssl not available — API key stored without encryption', array( 'option' => $option_name ) );
            update_option( $option_name, $plaintext );
            return;
        }

        $encrypted = self::encrypt( $plaintext );
        update_option( $option_name, self::ENCRYPTED_PREFIX . $encrypted );
    }

    public static function openssl_available(): bool {
        return function_exists( 'openssl_encrypt' )
            && in_array( self::CIPHER, openssl_get_cipher_methods(), true );
    }

    private static function encrypt( string $plaintext ): string {
        $iv  = openssl_random_pseudo_bytes( openssl_cipher_iv_length( self::CIPHER ) );
        $enc = openssl_encrypt( $plaintext, self::CIPHER, self::get_secret(), 0, $iv );
        return base64_encode( $iv . '::' . $enc );
    }

    private static function decrypt( string $encoded ): string {
        if ( ! self::openssl_available() ) {
            return '';
        }

        $decoded = base64_decode( $encoded, true );
        if ( $decoded === false ) {
            FG_Logger::error( 'FG_Crypto: base64 decode failed — key may be corrupted' );
            return '';
        }

        $parts = explode( '::', $decoded, 2 );
        if ( count( $parts ) !== 2 ) {
            FG_Logger::error( 'FG_Crypto: unexpected ciphertext format' );
            return '';
        }

        [ $iv, $ciphertext ] = $parts;

        $plaintext = openssl_decrypt( $ciphertext, self::CIPHER, self::get_secret(), 0, $iv );

        if ( $plaintext === false ) {
            $plaintext = openssl_decrypt( $ciphertext, self::CIPHER, self::get_legacy_secret(), 0, $iv );
        }

        if ( $plaintext === false ) {
            FG_Logger::error( 'FG_Crypto: decryption failed — SECURE_AUTH_KEY may have changed' );
            return '';
        }

        return $plaintext;
    }

    private static function get_secret(): string {
        $base = defined( 'SECURE_AUTH_KEY' ) && SECURE_AUTH_KEY !== ''
            ? SECURE_AUTH_KEY
            : ( AUTH_KEY ?? get_bloginfo( 'url' ) );
        return hash( 'sha256', $base, true );
    }

    private static function get_legacy_secret(): string {
        $base = defined( 'SECURE_AUTH_KEY' ) && SECURE_AUTH_KEY !== ''
            ? SECURE_AUTH_KEY
            : ( AUTH_KEY ?? get_bloginfo( 'url' ) );
        return substr( hash( 'sha256', $base ), 0, 32 );
    }
}
