<?php
/**
 * Application custom post type.
 *
 * Links a profile snapshot to an opportunity.
 * Stores the Bridge draft and tracks status over time.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Application {

    const POST_TYPE = 'fg_application';

    const STATUS_DRAFT       = 'draft';
    const STATUS_SUBMITTED   = 'submitted';
    const STATUS_APPROVED    = 'approved';
    const STATUS_REJECTED    = 'rejected';
    const STATUS_NO_RESPONSE = 'no_response';

    public static function register_post_type(): void {
        register_post_type( self::POST_TYPE, array(
            'labels'       => array(
                'name'          => __( 'Applications', 'f-grants' ),
                'singular_name' => __( 'Application', 'f-grants' ),
            ),
            'public'       => false,
            'show_ui'      => false,
            'show_in_menu' => false,
            'supports'     => array( 'title', 'custom-fields' ),
        ) );
    }

    /**
     * Get all applications, optionally filtered.
     *
     * @param  array $args  Optional query args (profile_id, status).
     * @return array
     */
    public static function get_all( array $args = array() ): array {
        $query_args = array(
            'post_type'      => self::POST_TYPE,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'date',
            'order'          => 'DESC',
            'meta_query'     => array(),
        );

        if ( ! empty( $args['profile_id'] ) ) {
            $query_args['meta_query'][] = array(
                'key'   => '_fg_profile_id',
                'value' => (int) $args['profile_id'],
            );
        }

        if ( ! empty( $args['status'] ) ) {
            $query_args['meta_query'][] = array(
                'key'   => '_fg_status',
                'value' => sanitize_text_field( $args['status'] ),
            );
        }

        $posts = get_posts( $query_args );

        return array_map( function( $post ) {
            return self::format( $post );
        }, $posts );
    }

    /**
     * Get applications for a specific profile.
     *
     * @param  int $profile_id
     * @return array
     */
    public static function get_by_profile( int $profile_id ): array {
        return self::get_all( array( 'profile_id' => $profile_id ) );
    }

    /**
     * Get a single application.
     *
     * @param  int $id
     * @return array|null
     */
    public static function get( int $id ): ?array {
        $post = get_post( $id );
        if ( ! $post || $post->post_type !== self::POST_TYPE ) {
            return null;
        }
        return self::format( $post );
    }

    /**
     * Format a WP_Post into a consistent array.
     *
     * @param  WP_Post $post
     * @return array
     */
    private static function format( $post ): array {
        $profile_snapshot_raw = get_post_meta( $post->ID, '_fg_profile_snapshot', true );
        $profile_snapshot     = $profile_snapshot_raw ? json_decode( $profile_snapshot_raw, true ) : array();

        return array(
            'ID'               => $post->ID,
            'title'            => $post->post_title,
            'profile_id'       => (int) get_post_meta( $post->ID, '_fg_profile_id', true ),
            'opportunity_id'   => (int) get_post_meta( $post->ID, '_fg_opportunity_id', true ),
            'profile_snapshot' => $profile_snapshot,
            'draft_output'     => get_post_meta( $post->ID, '_fg_draft_output', true ),
            'advocacy_context' => get_post_meta( $post->ID, '_fg_advocacy_context', true ),
            'status'           => get_post_meta( $post->ID, '_fg_status', true ) ?: self::STATUS_DRAFT,
            'notes'            => get_post_meta( $post->ID, '_fg_notes', true ),
            'date'             => $post->post_date,
        );
    }

    /**
     * Insert a new application.
     *
     * Snapshots the profile at time of creation so future profile edits
     * don't mutate past drafts.
     *
     * @param  array $data  Requires profile_id, opportunity_id.
     * @return int|WP_Error
     */
    public static function insert( array $data ) {
        $profile_id     = (int) ( $data['profile_id'] ?? 0 );
        $opportunity_id = (int) ( $data['opportunity_id'] ?? 0 );

        $profile     = FG_Profile::get( $profile_id );
        $opportunity = FG_Opportunity::get( $opportunity_id );

        if ( ! $profile || ! $opportunity ) {
            return new WP_Error( 'invalid_ids', __( 'Profile or Opportunity not found.', 'f-grants' ) );
        }

        $title = sprintf(
            '%s — %s',
            $profile['entity_name'],
            $opportunity['title']
        );

        $post_id = wp_insert_post( array(
            'post_type'   => self::POST_TYPE,
            'post_status' => 'publish',
            'post_title'  => sanitize_text_field( $title ),
        ), true );

        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        update_post_meta( $post_id, '_fg_profile_id',       $profile_id );
        update_post_meta( $post_id, '_fg_opportunity_id',   $opportunity_id );
        update_post_meta( $post_id, '_fg_profile_snapshot', wp_json_encode( $profile ) );
        update_post_meta( $post_id, '_fg_advocacy_context', wp_kses_post( $data['advocacy_context'] ?? '' ) );
        update_post_meta( $post_id, '_fg_status',           self::STATUS_DRAFT );
        update_post_meta( $post_id, '_fg_draft_output',     '' );
        update_post_meta( $post_id, '_fg_notes',            '' );

        return $post_id;
    }

    /**
     * Save the Bridge draft output to an application.
     *
     * @param  int    $id
     * @param  string $draft
     */
    public static function save_draft( int $id, string $draft ): void {
        update_post_meta( $id, '_fg_draft_output', wp_kses_post( $draft ) );
    }

    /**
     * Update application status and notes.
     *
     * @param  int    $id
     * @param  string $status
     * @param  string $notes
     * @return bool
     */
    public static function update_status( int $id, string $status, string $notes = '' ): bool {
        $valid_statuses = array(
            self::STATUS_DRAFT,
            self::STATUS_SUBMITTED,
            self::STATUS_APPROVED,
            self::STATUS_REJECTED,
            self::STATUS_NO_RESPONSE,
        );

        if ( ! in_array( $status, $valid_statuses, true ) ) {
            return false;
        }

        update_post_meta( $id, '_fg_status', $status );
        if ( $notes !== '' ) {
            update_post_meta( $id, '_fg_notes', sanitize_textarea_field( $notes ) );
        }

        // Log outcome for profile sharpening
        FG_Outcome::log( $id, $status, $notes );

        return true;
    }

    /**
     * Delete an application and its outcome log.
     *
     * @param  int $id
     * @return bool
     */
    public static function delete( int $id ): bool {
        return (bool) wp_delete_post( $id, true );
    }

    /**
     * Get readable status labels.
     *
     * @return array
     */
    public static function get_statuses(): array {
        return array(
            self::STATUS_DRAFT       => __( 'Draft', 'f-grants' ),
            self::STATUS_SUBMITTED   => __( 'Submitted', 'f-grants' ),
            self::STATUS_APPROVED    => __( 'Approved', 'f-grants' ),
            self::STATUS_REJECTED    => __( 'Rejected', 'f-grants' ),
            self::STATUS_NO_RESPONSE => __( 'No Response', 'f-grants' ),
        );
    }
}
