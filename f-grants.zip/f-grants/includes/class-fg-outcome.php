<?php
/**
 * Outcome log — stored as post meta on fg_application.
 *
 * Every logged outcome feeds the profile sharpening loop.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Outcome {

    const META_KEY = '_fg_outcome_log';

    /**
     * Log an outcome entry for an application.
     *
     * @param  int    $application_id
     * @param  string $outcome         One of FG_Application status constants.
     * @param  string $writer_notes
     */
    public static function log( int $application_id, string $outcome, string $writer_notes = '' ): void {
        $log   = self::get_log( $application_id );
        $log[] = array(
            'outcome'      => sanitize_text_field( $outcome ),
            'writer_notes' => sanitize_textarea_field( $writer_notes ),
            'date'         => current_time( 'mysql', true ),
        );

        update_post_meta( $application_id, self::META_KEY, wp_json_encode( $log ) );
    }

    /**
     * Get the full outcome log for an application.
     *
     * @param  int $application_id
     * @return array
     */
    public static function get_log( int $application_id ): array {
        $raw = get_post_meta( $application_id, self::META_KEY, true );
        if ( empty( $raw ) ) {
            return array();
        }
        $decoded = json_decode( $raw, true );
        return is_array( $decoded ) ? $decoded : array();
    }

    /**
     * Get all outcome logs across applications for a given profile.
     * Used by Claude's profile sharpening to understand patterns over time.
     *
     * @param  int $profile_id
     * @return array  Array of [ application_title, opportunity_title, outcome, notes, date ]
     */
    public static function get_for_profile( int $profile_id ): array {
        $applications = FG_Application::get_by_profile( $profile_id );
        $all_outcomes = array();

        foreach ( $applications as $app ) {
            $opportunity = FG_Opportunity::get( $app['opportunity_id'] );
            $log         = self::get_log( $app['ID'] );

            foreach ( $log as $entry ) {
                $all_outcomes[] = array(
                    'application_title' => $app['title'],
                    'funder_name'       => $opportunity['funder_name'] ?? '',
                    'opportunity_title' => $opportunity['title'] ?? '',
                    'outcome'           => $entry['outcome'],
                    'writer_notes'      => $entry['writer_notes'],
                    'date'              => $entry['date'],
                );
            }
        }

        // Sort by date ascending so Claude sees the full arc
        usort( $all_outcomes, function( $a, $b ) {
            return strcmp( $a['date'], $b['date'] );
        } );

        return $all_outcomes;
    }
}
