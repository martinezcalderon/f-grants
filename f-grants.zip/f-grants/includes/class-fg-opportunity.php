<?php
/**
 * Opportunity custom post type.
 *
 * Stores funder criteria — raw input and Claude's structured extraction.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Opportunity {

    const POST_TYPE = 'fg_opportunity';

    public static function register_post_type(): void {
        register_post_type( self::POST_TYPE, array(
            'labels'       => array(
                'name'          => __( 'Opportunities', 'f-grants' ),
                'singular_name' => __( 'Opportunity', 'f-grants' ),
            ),
            'public'       => false,
            'show_ui'      => false,
            'show_in_menu' => false,
            'supports'     => array( 'title', 'custom-fields' ),
        ) );
    }

    /**
     * Get all opportunities.
     *
     * @return array  Array of WP_Post objects as arrays.
     */
    public static function get_all(): array {
        $posts = get_posts( array(
            'post_type'      => self::POST_TYPE,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ) );

        return array_map( function( $post ) {
            return array(
                'ID'                => $post->ID,
                'title'             => $post->post_title,
                'funder_name'       => get_post_meta( $post->ID, '_fg_funder_name', true ),
                'deadline'          => get_post_meta( $post->ID, '_fg_deadline', true ),
                'extracted_criteria' => self::get_criteria( $post->ID ),
                'date'              => $post->post_date,
            );
        }, $posts );
    }

    /**
     * Get a single opportunity.
     *
     * @param  int $id
     * @return array|null
     */
    public static function get( int $id ): ?array {
        $post = get_post( $id );
        if ( ! $post || $post->post_type !== self::POST_TYPE ) {
            return null;
        }

        return array(
            'ID'                 => $post->ID,
            'title'              => $post->post_title,
            'funder_name'        => get_post_meta( $id, '_fg_funder_name', true ),
            'raw_input'          => get_post_meta( $id, '_fg_raw_input', true ),
            'extracted_criteria' => self::get_criteria( $id ),
            'deadline'           => get_post_meta( $id, '_fg_deadline', true ),
            'date'               => $post->post_date,
        );
    }

    /**
     * Get decoded criteria JSON for an opportunity.
     *
     * @param  int $id
     * @return array
     */
    public static function get_criteria( int $id ): array {
        $raw = get_post_meta( $id, '_fg_extracted_criteria', true );
        if ( empty( $raw ) ) {
            return array();
        }
        $decoded = json_decode( $raw, true );
        return is_array( $decoded ) ? $decoded : array();
    }

    /**
     * Insert a new opportunity.
     *
     * @param  array $data
     * @return int|WP_Error  Post ID or error.
     */
    public static function insert( array $data ) {
        $post_id = wp_insert_post( array(
            'post_type'   => self::POST_TYPE,
            'post_status' => 'publish',
            'post_title'  => sanitize_text_field( $data['title'] ?? __( 'Untitled Opportunity', 'f-grants' ) ),
        ), true );

        if ( is_wp_error( $post_id ) ) {
            return $post_id;
        }

        update_post_meta( $post_id, '_fg_funder_name', sanitize_text_field( $data['funder_name'] ?? '' ) );
        update_post_meta( $post_id, '_fg_raw_input',   wp_kses_post( $data['raw_input'] ?? '' ) );
        update_post_meta( $post_id, '_fg_deadline',    sanitize_text_field( $data['deadline'] ?? '' ) );

        return $post_id;
    }

    /**
     * Save Claude's extracted criteria to an opportunity.
     *
     * @param  int   $id
     * @param  array $criteria
     */
    public static function save_criteria( int $id, array $criteria ): void {
        update_post_meta( $id, '_fg_extracted_criteria', wp_json_encode( $criteria ) );
    }

    /**
     * Delete an opportunity.
     *
     * @param  int $id
     * @return bool
     */
    public static function delete( int $id ): bool {
        return (bool) wp_delete_post( $id, true );
    }
}
