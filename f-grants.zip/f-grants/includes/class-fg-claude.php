<?php
/**
 * Claude AI layer.
 *
 * Handles all four AI moments:
 *   1. Criteria extraction      — on Opportunity creation
 *   2. Practice dialogue        — artist segment only
 *   3. Bridge generation        — core output
 *   4. Profile sharpening       — compounding intelligence loop
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Claude {

    const API_URL = 'https://api.anthropic.com/v1/messages';
    const MODEL   = 'claude-sonnet-4-6';

    // -------------------------------------------------------------------------
    // 01 — Criteria Extraction
    // -------------------------------------------------------------------------

    /**
     * Read raw funder input and return structured criteria.
     *
     * @param  string $raw_input  Pasted text or URL content from funder.
     * @return array|WP_Error     Structured criteria array or error.
     */
    public static function extract_criteria( string $raw_input ) {
        $prompt = <<<PROMPT
You are analyzing a grant opportunity for a writer who needs to understand exactly what a funder cares about.

Read the following funder material and extract the key information. Return ONLY valid JSON — no preamble, no explanation, no markdown fences.

Return this exact structure:
{
  "eligibility": ["requirement 1", "requirement 2"],
  "priorities": ["priority 1", "priority 2"],
  "values_language": ["phrase or value signal 1", "phrase or value signal 2"],
  "tone": "brief description of the funder's communication style",
  "implicit_signals": ["what they seem to actually fund vs what they say", "any patterns worth noting"],
  "red_flags": ["any eligibility issues or misalignment signals to watch for"]
}

FUNDER MATERIAL:
$raw_input
PROMPT;

        $response = self::call( $prompt );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $decoded = json_decode( $response, true );
        if ( ! is_array( $decoded ) ) {
            FG_Logger::error( 'FG_Claude::extract_criteria — JSON parse failed', array( 'raw' => substr( $response, 0, 200 ) ) );
            return new WP_Error( 'parse_error', __( 'Could not parse criteria from Claude response.', 'f-grants' ) );
        }

        return $decoded;
    }

    // -------------------------------------------------------------------------
    // 02 — Practice Dialogue (artist segment only)
    // -------------------------------------------------------------------------

    /**
     * Continue a conversational intake with an artist about their practice.
     *
     * @param  array  $profile   Current profile data.
     * @param  string $message   Artist's latest message.
     * @param  array  $history   Prior conversation turns [['role'=>'user','content'=>'...'], ...].
     * @return string|WP_Error   Claude's next response.
     */
    public static function practice_dialogue( array $profile, string $message, array $history ) {
        $system = <<<SYSTEM
You are helping an artist find language for their practice that isn't filtered through ego or habit.

Your job is NOT to ask "describe your practice." Your job is to ask questions that surface:
- How their work actually lands with audiences
- What problems the work creates or solves
- What the artist keeps returning to without fully knowing why
- What they avoid saying publicly but that's actually central to the work

You are not a therapist. You are a sharp, curious reader who is interested in the work itself, not the artist's brand. 
Ask one question at a time. Be direct. Be specific. Never flatter.

ARTIST NAME: {$profile['entity_name']}
WHAT WE KNOW SO FAR:
{$profile['description']}
SYSTEM;

        $messages = $history;
        $messages[] = array( 'role' => 'user', 'content' => $message );

        return self::call_with_messages( $system, $messages );
    }

    // -------------------------------------------------------------------------
    // 03 — Bridge Generation
    // -------------------------------------------------------------------------

    /**
     * Generate the core Bridge draft narrative.
     *
     * @param  array  $profile            Full profile data.
     * @param  array  $criteria           Extracted opportunity criteria.
     * @param  string $advocacy_context   Optional external conditions / positioning notes.
     * @return string|WP_Error            Working draft narrative.
     */
    public static function generate_bridge( array $profile, array $criteria, string $advocacy_context = '' ) {
        $segment_context = self::get_segment_context( $profile['segment'] ?? 'nonprofit' );

        $criteria_formatted = wp_json_encode( $criteria, JSON_PRETTY_PRINT );

        $advocacy_block = $advocacy_context
            ? "ADVOCACY CONTEXT (external conditions affecting this applicant's work):\n$advocacy_context"
            : '';

        $history_summary = '';
        if ( ! empty( $profile['history_log'] ) ) {
            $log = json_decode( $profile['history_log'], true );
            if ( is_array( $log ) && ! empty( $log ) ) {
                $history_summary = "APPLICANT HISTORY LOG (past outcomes and learnings):\n" . wp_json_encode( array_slice( $log, -10 ), JSON_PRETTY_PRINT );
            }
        }

        $prompt = <<<PROMPT
You are a skilled grant writer producing a working draft narrative.

Your job is to write a bridge — a narrative that:
1. Positions the applicant's work against the funder's values in a credible, specific way
2. Is written in the applicant's voice (not generic grant-speak)
3. Acknowledges relevant external conditions honestly, not defensively
4. Makes the strongest credible case — not the most flattering one
5. Leaves room for the writer to edit and make it their own

This is a WORKING DRAFT for review — not a final submission. Write it as something worth editing, not something to submit blindly.

$segment_context

APPLICANT PROFILE:
Name: {$profile['entity_name']}
Segment: {$profile['segment']}
Description: {$profile['description']}
Voice sample (how they actually write):
{$profile['voice_sample']}

$history_summary

FUNDER CRITERIA (extracted and structured):
$criteria_formatted

$advocacy_block

Write the bridge narrative now. 3–5 paragraphs. No headers. No bullet points. Prose only.
PROMPT;

        return self::call( $prompt );
    }

    // -------------------------------------------------------------------------
    // 04 — Profile Sharpening
    // -------------------------------------------------------------------------

    /**
     * Read the outcome log for a profile and return a suggested history entry.
     *
     * @param  int $profile_id
     * @return array|WP_Error  Suggested history entry with 'note' and 'signals'.
     */
    public static function sharpen_profile( int $profile_id ) {
        $profile  = FG_Profile::get( $profile_id );
        $outcomes = FG_Outcome::get_for_profile( $profile_id );

        if ( ! $profile ) {
            return new WP_Error( 'not_found', __( 'Profile not found.', 'f-grants' ) );
        }

        if ( empty( $outcomes ) ) {
            return new WP_Error( 'no_outcomes', __( 'No outcome data to learn from yet.', 'f-grants' ) );
        }

        $outcomes_formatted = wp_json_encode( $outcomes, JSON_PRETTY_PRINT );

        $prompt = <<<PROMPT
You are analyzing a grant applicant's track record to surface patterns that will sharpen future applications.

Review the outcome log below and return ONLY valid JSON with this structure:
{
  "note": "1–2 sentence plain-language summary of what the data suggests about how this applicant's work is landing with funders",
  "signals": ["signal 1", "signal 2"],
  "suggested_framing_shifts": ["what to lean into", "what to reframe or drop"],
  "caution": "anything the writer should be careful about based on the patterns"
}

APPLICANT: {$profile['entity_name']}
CURRENT DESCRIPTION: {$profile['description']}

OUTCOME LOG:
$outcomes_formatted
PROMPT;

        $response = self::call( $prompt );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $decoded = json_decode( $response, true );
        if ( ! is_array( $decoded ) ) {
            return new WP_Error( 'parse_error', __( 'Could not parse sharpening response.', 'f-grants' ) );
        }

        return $decoded;
    }

    /**
     * Cron callback — sharpen all profiles that have outcome data.
     */
    public static function cron_sharpen_profiles(): void {
        $profiles = FG_Profile::get_all();

        foreach ( $profiles as $profile ) {
            $outcomes = FG_Outcome::get_for_profile( (int) $profile['id'] );
            if ( empty( $outcomes ) ) {
                continue;
            }

            $result = self::sharpen_profile( (int) $profile['id'] );
            if ( is_wp_error( $result ) ) {
                FG_Logger::error( 'Profile sharpening failed', array(
                    'profile_id' => $profile['id'],
                    'error'      => $result->get_error_message(),
                ) );
                continue;
            }

            FG_Profile::append_history( (int) $profile['id'], array(
                'type'                     => 'auto_sharpening',
                'note'                     => $result['note'] ?? '',
                'signals'                  => $result['signals'] ?? array(),
                'suggested_framing_shifts' => $result['suggested_framing_shifts'] ?? array(),
                'caution'                  => $result['caution'] ?? '',
            ) );

            FG_Logger::info( 'Profile sharpened', array( 'profile_id' => $profile['id'] ) );
        }
    }

    // -------------------------------------------------------------------------
    // Internal helpers
    // -------------------------------------------------------------------------

    /**
     * Make a single-turn API call.
     *
     * @param  string $prompt
     * @return string|WP_Error
     */
    private static function call( string $prompt ) {
        return self::call_with_messages( '', array(
            array( 'role' => 'user', 'content' => $prompt ),
        ) );
    }

    /**
     * Make a multi-turn API call with system prompt.
     *
     * @param  string $system
     * @param  array  $messages
     * @return string|WP_Error
     */
    private static function call_with_messages( string $system, array $messages ) {
        $api_key = FG_Crypto::get_key( FG_Crypto::CLAUDE_KEY_OPTION );

        if ( empty( $api_key ) ) {
            return new WP_Error( 'no_api_key', __( 'Claude API key is not configured. Please add it in F! Grants → Settings.', 'f-grants' ) );
        }

        $body = array(
            'model'      => get_option( 'fg_claude_model', self::MODEL ),
            'max_tokens' => 2048,
            'messages'   => $messages,
        );

        if ( ! empty( $system ) ) {
            $body['system'] = $system;
        }

        $response = wp_remote_post( self::API_URL, array(
            'timeout' => 60,
            'headers' => array(
                'x-api-key'         => $api_key,
                'anthropic-version' => '2023-06-01',
                'content-type'      => 'application/json',
            ),
            'body'    => wp_json_encode( $body ),
        ) );

        if ( is_wp_error( $response ) ) {
            FG_Logger::error( 'Claude API request failed', array( 'error' => $response->get_error_message() ) );
            return $response;
        }

        $status = wp_remote_retrieve_response_code( $response );
        $raw    = wp_remote_retrieve_body( $response );

        if ( $status !== 200 ) {
            FG_Logger::error( 'Claude API non-200', array( 'status' => $status, 'body' => substr( $raw, 0, 300 ) ) );
            return new WP_Error( 'api_error', sprintf( __( 'Claude API returned status %d.', 'f-grants' ), $status ) );
        }

        $data = json_decode( $raw, true );

        $content = $data['content'][0]['text'] ?? '';

        if ( empty( $content ) ) {
            return new WP_Error( 'empty_response', __( 'Claude returned an empty response.', 'f-grants' ) );
        }

        // Strip JSON fences if present
        $content = preg_replace( '/^```(?:json)?\s*/i', '', trim( $content ) );
        $content = preg_replace( '/\s*```$/', '', $content );

        return $content;
    }

    /**
     * Get segment-specific context to inject into the Bridge prompt.
     *
     * @param  string $segment
     * @return string
     */
    private static function get_segment_context( string $segment ): string {
        $contexts = array(
            'nonprofit' => 'SEGMENT CONTEXT: This applicant is a nonprofit. Their application needs to bridge institutional mission to funder priorities, acknowledge the political or policy context affecting their work, and speak in organizational voice — clear, credible, not corporate.',
            'artist'    => 'SEGMENT CONTEXT: This applicant is an individual artist. Their application needs to bridge their creative practice to the funder\'s values without flattening it into mission-statement language. Write in first person. The voice must feel like a real person, not a grant writer.',
            'consultant' => 'SEGMENT CONTEXT: This applicant\'s profile is managed by a consultant on behalf of a client. Write in the client\'s voice, not the consultant\'s. The narrative should read as if the client wrote it themselves.',
        );

        return $contexts[ $segment ] ?? $contexts['nonprofit'];
    }
}
