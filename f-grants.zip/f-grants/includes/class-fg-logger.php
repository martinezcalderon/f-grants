<?php
/**
 * Simple file-based logger for F! Grants.
 * Mirrors FI_Logger from F! Insights.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Logger {

    const LOG_OPTION = 'fg_debug_log_enabled';

    public static function get_log_file(): string {
        return WP_CONTENT_DIR . '/fg-debug.log';
    }

    public static function is_enabled(): bool {
        return get_option( self::LOG_OPTION, '0' ) === '1';
    }

    public static function info( string $message, array $context = array() ): void {
        self::write( 'INFO', $message, $context );
    }

    public static function warning( string $message, array $context = array() ): void {
        self::write( 'WARNING', $message, $context );
    }

    public static function error( string $message, array $context = array() ): void {
        self::write( 'ERROR', $message, $context );
    }

    private static function write( string $level, string $message, array $context ): void {
        if ( ! self::is_enabled() && $level !== 'ERROR' ) {
            return;
        }

        $line = sprintf(
            '[%s] [%s] %s %s',
            gmdate( 'Y-m-d H:i:s' ),
            $level,
            $message,
            empty( $context ) ? '' : wp_json_encode( $context )
        );

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        file_put_contents( self::get_log_file(), $line . PHP_EOL, FILE_APPEND | LOCK_EX );
    }

    public static function clear(): void {
        $file = self::get_log_file();
        if ( file_exists( $file ) ) {
            // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
            unlink( $file );
        }
    }
}
