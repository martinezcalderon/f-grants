<?php
/**
 * Premium feature gate.
 *
 * Single source of truth for whether a premium license is active.
 * Every class that needs to check premium status calls FG_Premium::is_active().
 *
 * Freemius integration path:
 *   1. Install the Freemius SDK into /freemius/
 *   2. Bootstrap it in f-grants.php (see Freemius docs)
 *   3. Replace the body of is_active() with:
 *          return function_exists( 'fs_f_grants' ) && fs_f_grants()->is__premium_only();
 *
 * Until the SDK is integrated this returns false so the free-tier UX
 * is the default for all premium gates.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Premium {

    /**
     * Returns true if a premium license is active.
     *
     * @return bool
     */
    public static function is_active(): bool {
        // Freemius SDK integration point — replace this line when SDK is added:
        // return function_exists( 'fs_f_grants' ) && fs_f_grants()->is__premium_only();
        return false;
    }
}
