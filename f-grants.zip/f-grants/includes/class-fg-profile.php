<?php
/**
 * Applicant Profile CRUD.
 *
 * Profiles live in a custom table (not a CPT) because they are
 * first-class persistent entities with structured JSON fields
 * that compound over time.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Profile {

    const SEGMENT_NONPROFIT = 'nonprofit';
    const SEGMENT_ARTIST    = 'artist';
    const SEGMENT_CONSULTANT = 'consultant';

    const PROFILE_LIMIT_FREE = 3;

    /**
     * Get all profiles.
     *
     * @return array
     */
    public static function get_all(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'fg_profiles';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $results = $wpdb->get_results( "SELECT * FROM $table ORDER BY created_at DESC", ARRAY_A );
        return $results ?: array();
    }

    /**
     * Get a single profile by ID.
     *
     * @param  int $id
     * @return array|null
     */
    public static function get( int $id ): ?array {
        global $wpdb;
        $table = $wpdb->prefix . 'fg_profiles';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $row = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM $table WHERE id = %d", $id ),
            ARRAY_A
        );
        return $row ?: null;
    }

    /**
     * Count total profiles.
     *
     * @return int
     */
    public static function count(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'fg_profiles';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        return (int) $wpdb->get_var( "SELECT COUNT(*) FROM $table" );
    }

    /**
     * Check if a new profile can be created (free tier limit).
     *
     * @return bool
     */
    public static function can_create(): bool {
        if ( FG_Premium::is_active() ) {
            return true;
        }
        return self::count() < self::PROFILE_LIMIT_FREE;
    }

    /**
     * Insert a new profile.
     *
     * @param  array $data
     * @return int|false  New profile ID or false on failure.
     */
    public static function insert( array $data ) {
        if ( ! self::can_create() ) {
            return false;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'fg_profiles';
        $now   = current_time( 'mysql', true );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $result = $wpdb->insert(
            $table,
            array(
                'segment'      => sanitize_text_field( $data['segment'] ?? self::SEGMENT_NONPROFIT ),
                'entity_name'  => sanitize_text_field( $data['entity_name'] ?? '' ),
                'description'  => wp_kses_post( $data['description'] ?? '' ),
                'voice_sample' => wp_kses_post( $data['voice_sample'] ?? '' ),
                'history_log'  => wp_json_encode( array() ),
                'created_at'   => $now,
                'updated_at'   => $now,
            ),
            array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
        );

        return $result ? $wpdb->insert_id : false;
    }

    /**
     * Update an existing profile.
     *
     * @param  int   $id
     * @param  array $data
     * @return bool
     */
    public static function update( int $id, array $data ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'fg_profiles';

        $update = array( 'updated_at' => current_time( 'mysql', true ) );

        if ( isset( $data['segment'] ) ) {
            $update['segment'] = sanitize_text_field( $data['segment'] );
        }
        if ( isset( $data['entity_name'] ) ) {
            $update['entity_name'] = sanitize_text_field( $data['entity_name'] );
        }
        if ( isset( $data['description'] ) ) {
            $update['description'] = wp_kses_post( $data['description'] );
        }
        if ( isset( $data['voice_sample'] ) ) {
            $update['voice_sample'] = wp_kses_post( $data['voice_sample'] );
        }
        if ( isset( $data['history_log'] ) ) {
            $update['history_log'] = wp_json_encode( $data['history_log'] );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $result = $wpdb->update(
            $table,
            $update,
            array( 'id' => $id ),
            null,
            array( '%d' )
        );

        return $result !== false;
    }

    /**
     * Delete a profile and all associated applications.
     *
     * @param  int $id
     * @return bool
     */
    public static function delete( int $id ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'fg_profiles';

        // Delete associated applications
        $apps = FG_Application::get_by_profile( $id );
        foreach ( $apps as $app ) {
            FG_Application::delete( (int) $app['ID'] );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        $result = $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );
        return $result !== false;
    }

    /**
     * Append an entry to a profile's history log.
     *
     * @param  int   $id
     * @param  array $entry  e.g. ['type' => 'sharpening', 'note' => '...', 'date' => '...']
     * @return bool
     */
    public static function append_history( int $id, array $entry ): bool {
        $profile = self::get( $id );
        if ( ! $profile ) {
            return false;
        }

        $log   = json_decode( $profile['history_log'] ?? '[]', true ) ?: array();
        $log[] = array_merge( $entry, array( 'date' => current_time( 'mysql', true ) ) );

        // Keep log to last 50 entries to avoid unbounded growth
        if ( count( $log ) > 50 ) {
            $log = array_slice( $log, -50 );
        }

        return self::update( $id, array( 'history_log' => $log ) );
    }

    /**
     * Get valid segment options.
     *
     * @return array
     */
    public static function get_segments(): array {
        return array(
            self::SEGMENT_NONPROFIT  => __( 'Nonprofit', 'f-grants' ),
            self::SEGMENT_ARTIST     => __( 'Artist / Individual', 'f-grants' ),
            self::SEGMENT_CONSULTANT => __( 'Consultant', 'f-grants' ),
        );
    }
}
