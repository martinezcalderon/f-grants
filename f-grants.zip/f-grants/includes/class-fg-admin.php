<?php
/**
 * Admin pages and form handling for F! Grants.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Admin {

    public static function register_hooks(): void {
        add_action( 'admin_init', array( __CLASS__, 'handle_admin_actions' ) );
    }

    // -------------------------------------------------------------------------
    // Action Router
    // -------------------------------------------------------------------------

    public static function handle_admin_actions(): void {
        if ( ! isset( $_GET['page'] ) || strpos( $_GET['page'], 'f-grants' ) === false ) {
            return;
        }
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }

        // Save settings
        if ( isset( $_POST['fg_save_settings'] ) && check_admin_referer( 'fg_settings_nonce' ) ) {
            self::save_settings();
            wp_redirect( admin_url( 'admin.php?page=f-grants-settings&saved=1' ) );
            exit;
        }

        // Save profile
        if ( isset( $_POST['fg_save_profile'] ) && check_admin_referer( 'fg_profile_nonce' ) ) {
            self::save_profile();
            // redirect happens inside save_profile()
        }

        // Delete profile
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete_profile'
            && isset( $_GET['profile_id'] ) && check_admin_referer( 'fg_delete_profile_' . absint( $_GET['profile_id'] ) ) ) {
            FG_Profile::delete( absint( $_GET['profile_id'] ) );
            wp_redirect( admin_url( 'admin.php?page=f-grants-profiles&deleted=1' ) );
            exit;
        }

        // Save opportunity
        if ( isset( $_POST['fg_save_opportunity'] ) && check_admin_referer( 'fg_opportunity_nonce' ) ) {
            self::save_opportunity();
        }

        // Delete opportunity
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete_opportunity'
            && isset( $_GET['opp_id'] ) && check_admin_referer( 'fg_delete_opp_' . absint( $_GET['opp_id'] ) ) ) {
            FG_Opportunity::delete( absint( $_GET['opp_id'] ) );
            wp_redirect( admin_url( 'admin.php?page=f-grants-opportunities&deleted=1' ) );
            exit;
        }

        // Save application
        if ( isset( $_POST['fg_save_application'] ) && check_admin_referer( 'fg_application_nonce' ) ) {
            self::save_application();
        }

        // Update application status
        if ( isset( $_POST['fg_update_status'] ) && check_admin_referer( 'fg_status_nonce' ) ) {
            self::update_application_status();
        }

        // Delete application
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete_application'
            && isset( $_GET['app_id'] ) && check_admin_referer( 'fg_delete_app_' . absint( $_GET['app_id'] ) ) ) {
            FG_Application::delete( absint( $_GET['app_id'] ) );
            wp_redirect( admin_url( 'admin.php?page=f-grants-applications&deleted=1' ) );
            exit;
        }

        // Clear debug log
        if ( isset( $_GET['action'] ) && $_GET['action'] === 'clear_log'
            && check_admin_referer( 'fg_clear_log' ) ) {
            FG_Logger::clear();
            wp_redirect( admin_url( 'admin.php?page=f-grants-settings&tab=debug&log_cleared=1' ) );
            exit;
        }
    }

    // -------------------------------------------------------------------------
    // Dashboard
    // -------------------------------------------------------------------------

    public static function render_dashboard(): void {
        $profiles     = FG_Profile::get_all();
        $applications = FG_Application::get_all();
        $opportunities = FG_Opportunity::get_all();

        $stats = array(
            'profiles'     => count( $profiles ),
            'opportunities' => count( $opportunities ),
            'applications' => count( $applications ),
            'approved'     => count( array_filter( $applications, fn( $a ) => $a['status'] === FG_Application::STATUS_APPROVED ) ),
        );
        ?>
        <div class="wrap fg-wrap">
            <h1><?php esc_html_e( 'F! Grants', 'f-grants' ); ?></h1>
            <p class="fg-subtitle"><?php esc_html_e( 'Positioning and advocacy intelligence for grant writers.', 'f-grants' ); ?></p>

            <div class="fg-stats-row">
                <div class="fg-stat">
                    <span class="fg-stat-number"><?php echo esc_html( $stats['profiles'] ); ?></span>
                    <span class="fg-stat-label"><?php esc_html_e( 'Profiles', 'f-grants' ); ?></span>
                </div>
                <div class="fg-stat">
                    <span class="fg-stat-number"><?php echo esc_html( $stats['opportunities'] ); ?></span>
                    <span class="fg-stat-label"><?php esc_html_e( 'Opportunities', 'f-grants' ); ?></span>
                </div>
                <div class="fg-stat">
                    <span class="fg-stat-number"><?php echo esc_html( $stats['applications'] ); ?></span>
                    <span class="fg-stat-label"><?php esc_html_e( 'Applications', 'f-grants' ); ?></span>
                </div>
                <div class="fg-stat">
                    <span class="fg-stat-number"><?php echo esc_html( $stats['approved'] ); ?></span>
                    <span class="fg-stat-label"><?php esc_html_e( 'Approved', 'f-grants' ); ?></span>
                </div>
            </div>

            <div class="fg-quick-actions">
                <h2><?php esc_html_e( 'Quick Actions', 'f-grants' ); ?></h2>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-profiles&action=new' ) ); ?>" class="button button-primary">
                    <?php esc_html_e( '+ New Profile', 'f-grants' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-opportunities&action=new' ) ); ?>" class="button">
                    <?php esc_html_e( '+ New Opportunity', 'f-grants' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-applications&action=new' ) ); ?>" class="button">
                    <?php esc_html_e( '+ New Application', 'f-grants' ); ?>
                </a>
            </div>

            <?php if ( ! empty( $applications ) ) : ?>
            <div class="fg-recent">
                <h2><?php esc_html_e( 'Recent Applications', 'f-grants' ); ?></h2>
                <table class="widefat striped fg-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Application', 'f-grants' ); ?></th>
                            <th><?php esc_html_e( 'Status', 'f-grants' ); ?></th>
                            <th><?php esc_html_e( 'Date', 'f-grants' ); ?></th>
                            <th><?php esc_html_e( 'Actions', 'f-grants' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( array_slice( $applications, 0, 5 ) as $app ) : ?>
                        <tr>
                            <td><?php echo esc_html( $app['title'] ); ?></td>
                            <td><span class="fg-status fg-status--<?php echo esc_attr( $app['status'] ); ?>"><?php echo esc_html( FG_Application::get_statuses()[ $app['status'] ] ?? $app['status'] ); ?></span></td>
                            <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $app['date'] ) ) ); ?></td>
                            <td><a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-applications&action=view&app_id=' . $app['ID'] ) ); ?>"><?php esc_html_e( 'View', 'f-grants' ); ?></a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

            <?php if ( empty( FG_Crypto::get_key( FG_Crypto::CLAUDE_KEY_OPTION ) ) ) : ?>
            <div class="notice notice-warning inline fg-notice">
                <p><?php printf(
                    /* translators: %s settings URL */
                    esc_html__( 'F! Grants needs a Claude API key to generate drafts. %s', 'f-grants' ),
                    '<a href="' . esc_url( admin_url( 'admin.php?page=f-grants-settings' ) ) . '">' . esc_html__( 'Add it in Settings →', 'f-grants' ) . '</a>'
                ); ?></p>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // Profiles
    // -------------------------------------------------------------------------

    public static function render_profiles_page(): void {
        $action = isset( $_GET['action'] ) ? sanitize_text_field( $_GET['action'] ) : 'list';
        $profile_id = isset( $_GET['profile_id'] ) ? absint( $_GET['profile_id'] ) : 0;

        if ( $action === 'new' || $action === 'edit' ) {
            self::render_profile_form( $profile_id );
            return;
        }

        $profiles = FG_Profile::get_all();
        $can_create = FG_Profile::can_create();
        ?>
        <div class="wrap fg-wrap">
            <h1><?php esc_html_e( 'Applicant Profiles', 'f-grants' ); ?></h1>

            <?php if ( isset( $_GET['deleted'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Profile deleted.', 'f-grants' ); ?></p></div>
            <?php endif; ?>

            <?php if ( $can_create ) : ?>
            <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-profiles&action=new' ) ); ?>" class="page-title-action"><?php esc_html_e( 'Add New', 'f-grants' ); ?></a>
            <?php else : ?>
            <p class="fg-limit-notice"><?php printf( esc_html__( 'You have reached the %d-profile limit for the free tier.', 'f-grants' ), FG_Profile::PROFILE_LIMIT_FREE ); ?></p>
            <?php endif; ?>

            <?php if ( empty( $profiles ) ) : ?>
            <p><?php esc_html_e( 'No profiles yet. Create your first one to get started.', 'f-grants' ); ?></p>
            <?php else : ?>
            <table class="widefat striped fg-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Name', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Segment', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Applications', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'f-grants' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $profiles as $profile ) :
                        $app_count = count( FG_Application::get_by_profile( (int) $profile['id'] ) );
                        $segments  = FG_Profile::get_segments();
                    ?>
                    <tr>
                        <td><strong><?php echo esc_html( $profile['entity_name'] ); ?></strong></td>
                        <td><?php echo esc_html( $segments[ $profile['segment'] ] ?? $profile['segment'] ); ?></td>
                        <td><?php echo esc_html( $app_count ); ?></td>
                        <td>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-profiles&action=edit&profile_id=' . $profile['id'] ) ); ?>"><?php esc_html_e( 'Edit', 'f-grants' ); ?></a>
                            &nbsp;|&nbsp;
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=f-grants-profiles&action=delete_profile&profile_id=' . $profile['id'] ), 'fg_delete_profile_' . $profile['id'] ) ); ?>"
                               onclick="return confirm('<?php esc_attr_e( 'Delete this profile and all its applications?', 'f-grants' ); ?>')"
                               class="fg-delete-link"><?php esc_html_e( 'Delete', 'f-grants' ); ?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function render_profile_form( int $profile_id = 0 ): void {
        $profile  = $profile_id ? FG_Profile::get( $profile_id ) : null;
        $segments = FG_Profile::get_segments();
        $is_edit  = ! empty( $profile );
        $history  = $profile ? json_decode( $profile['history_log'] ?? '[]', true ) : array();
        ?>
        <div class="wrap fg-wrap">
            <h1><?php echo $is_edit ? esc_html__( 'Edit Profile', 'f-grants' ) : esc_html__( 'New Profile', 'f-grants' ); ?></h1>

            <form method="post" action="">
                <?php wp_nonce_field( 'fg_profile_nonce' ); ?>
                <?php if ( $is_edit ) : ?>
                <input type="hidden" name="fg_profile_id" value="<?php echo esc_attr( $profile_id ); ?>">
                <?php endif; ?>
                <input type="hidden" name="fg_save_profile" value="1">

                <table class="form-table fg-form-table">
                    <tr>
                        <th><label for="fg_segment"><?php esc_html_e( 'Segment', 'f-grants' ); ?></label></th>
                        <td>
                            <select name="fg_segment" id="fg_segment">
                                <?php foreach ( $segments as $val => $label ) : ?>
                                <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $profile['segment'] ?? 'nonprofit', $val ); ?>><?php echo esc_html( $label ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="fg_entity_name"><?php esc_html_e( 'Name', 'f-grants' ); ?></label></th>
                        <td>
                            <input type="text" name="fg_entity_name" id="fg_entity_name" class="regular-text" value="<?php echo esc_attr( $profile['entity_name'] ?? '' ); ?>" required>
                            <p class="description"><?php esc_html_e( 'The name of the org, artist, or client this profile represents.', 'f-grants' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="fg_description"><?php esc_html_e( 'Description', 'f-grants' ); ?></label></th>
                        <td>
                            <textarea name="fg_description" id="fg_description" rows="8" class="large-text"><?php echo esc_textarea( $profile['description'] ?? '' ); ?></textarea>
                            <p class="description"><?php esc_html_e( 'Mission, programs, practice, geographic scope. What they do and why it matters. Be specific.', 'f-grants' ); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="fg_voice_sample"><?php esc_html_e( 'Voice Sample', 'f-grants' ); ?></label></th>
                        <td>
                            <textarea name="fg_voice_sample" id="fg_voice_sample" rows="6" class="large-text"><?php echo esc_textarea( $profile['voice_sample'] ?? '' ); ?></textarea>
                            <p class="description"><?php esc_html_e( 'Paste something they\'ve written — a past grant narrative, bio, artist statement. Claude uses this to match their voice.', 'f-grants' ); ?></p>
                        </td>
                    </tr>
                </table>

                <?php submit_button( $is_edit ? __( 'Update Profile', 'f-grants' ) : __( 'Create Profile', 'f-grants' ) ); ?>
            </form>

            <?php if ( $is_edit && ! empty( $history ) ) : ?>
            <hr>
            <h2><?php esc_html_e( 'Profile History', 'f-grants' ); ?></h2>
            <p class="description"><?php esc_html_e( 'Intelligence accumulated from past applications and sharpening cycles.', 'f-grants' ); ?></p>
            <div class="fg-history-log">
                <?php foreach ( array_reverse( $history ) as $entry ) : ?>
                <div class="fg-history-entry">
                    <span class="fg-history-date"><?php echo esc_html( $entry['date'] ?? '' ); ?></span>
                    <span class="fg-history-type"><?php echo esc_html( $entry['type'] ?? '' ); ?></span>
                    <p><?php echo esc_html( $entry['note'] ?? '' ); ?></p>
                    <?php if ( ! empty( $entry['signals'] ) ) : ?>
                    <ul><?php foreach ( (array) $entry['signals'] as $s ) echo '<li>' . esc_html( $s ) . '</li>'; ?></ul>
                    <?php endif; ?>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function save_profile(): void {
        $profile_id = isset( $_POST['fg_profile_id'] ) ? absint( $_POST['fg_profile_id'] ) : 0;

        $data = array(
            'segment'      => sanitize_text_field( $_POST['fg_segment'] ?? 'nonprofit' ),
            'entity_name'  => sanitize_text_field( $_POST['fg_entity_name'] ?? '' ),
            'description'  => wp_kses_post( $_POST['fg_description'] ?? '' ),
            'voice_sample' => wp_kses_post( $_POST['fg_voice_sample'] ?? '' ),
        );

        if ( $profile_id ) {
            FG_Profile::update( $profile_id, $data );
            wp_redirect( admin_url( 'admin.php?page=f-grants-profiles&action=edit&profile_id=' . $profile_id . '&saved=1' ) );
        } else {
            $new_id = FG_Profile::insert( $data );
            if ( $new_id ) {
                wp_redirect( admin_url( 'admin.php?page=f-grants-profiles&action=edit&profile_id=' . $new_id . '&saved=1' ) );
            } else {
                wp_redirect( admin_url( 'admin.php?page=f-grants-profiles&action=new&error=limit' ) );
            }
        }
        exit;
    }

    // -------------------------------------------------------------------------
    // Opportunities
    // -------------------------------------------------------------------------

    public static function render_opportunities_page(): void {
        $action = isset( $_GET['action'] ) ? sanitize_text_field( $_GET['action'] ) : 'list';
        $opp_id = isset( $_GET['opp_id'] ) ? absint( $_GET['opp_id'] ) : 0;

        if ( $action === 'new' || $action === 'edit' ) {
            self::render_opportunity_form( $opp_id );
            return;
        }

        $opportunities = FG_Opportunity::get_all();
        ?>
        <div class="wrap fg-wrap">
            <h1><?php esc_html_e( 'Opportunities', 'f-grants' ); ?></h1>

            <?php if ( isset( $_GET['deleted'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Opportunity deleted.', 'f-grants' ); ?></p></div>
            <?php endif; ?>

            <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-opportunities&action=new' ) ); ?>" class="page-title-action"><?php esc_html_e( 'Add New', 'f-grants' ); ?></a>

            <?php if ( empty( $opportunities ) ) : ?>
            <p><?php esc_html_e( 'No opportunities yet. Add one to start building a Bridge.', 'f-grants' ); ?></p>
            <?php else : ?>
            <table class="widefat striped fg-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Title', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Funder', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Deadline', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Criteria Extracted', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'f-grants' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $opportunities as $opp ) : ?>
                    <tr>
                        <td><strong><?php echo esc_html( $opp['title'] ); ?></strong></td>
                        <td><?php echo esc_html( $opp['funder_name'] ); ?></td>
                        <td><?php echo esc_html( $opp['deadline'] ); ?></td>
                        <td><?php echo empty( $opp['extracted_criteria'] ) ? '—' : '<span class="fg-badge fg-badge--yes">' . esc_html__( 'Yes', 'f-grants' ) . '</span>'; ?></td>
                        <td>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-opportunities&action=edit&opp_id=' . $opp['ID'] ) ); ?>"><?php esc_html_e( 'Edit', 'f-grants' ); ?></a>
                            &nbsp;|&nbsp;
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=f-grants-opportunities&action=delete_opportunity&opp_id=' . $opp['ID'] ), 'fg_delete_opp_' . $opp['ID'] ) ); ?>"
                               onclick="return confirm('<?php esc_attr_e( 'Delete this opportunity?', 'f-grants' ); ?>')"
                               class="fg-delete-link"><?php esc_html_e( 'Delete', 'f-grants' ); ?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function render_opportunity_form( int $opp_id = 0 ): void {
        $opp     = $opp_id ? FG_Opportunity::get( $opp_id ) : null;
        $is_edit = ! empty( $opp );
        $criteria = $opp ? $opp['extracted_criteria'] : array();
        ?>
        <div class="wrap fg-wrap">
            <h1><?php echo $is_edit ? esc_html__( 'Edit Opportunity', 'f-grants' ) : esc_html__( 'New Opportunity', 'f-grants' ); ?></h1>

            <?php if ( isset( $_GET['saved'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Opportunity saved.', 'f-grants' ); ?></p></div>
            <?php endif; ?>

            <form method="post" action="">
                <?php wp_nonce_field( 'fg_opportunity_nonce' ); ?>
                <?php if ( $is_edit ) : ?>
                <input type="hidden" name="fg_opp_id" value="<?php echo esc_attr( $opp_id ); ?>">
                <?php endif; ?>
                <input type="hidden" name="fg_save_opportunity" value="1">

                <table class="form-table fg-form-table">
                    <tr>
                        <th><label for="fg_opp_title"><?php esc_html_e( 'Title', 'f-grants' ); ?></label></th>
                        <td>
                            <input type="text" name="fg_opp_title" id="fg_opp_title" class="regular-text" value="<?php echo esc_attr( $opp['title'] ?? '' ); ?>" required>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="fg_funder_name"><?php esc_html_e( 'Funder Name', 'f-grants' ); ?></label></th>
                        <td>
                            <input type="text" name="fg_funder_name" id="fg_funder_name" class="regular-text" value="<?php echo esc_attr( $opp['funder_name'] ?? '' ); ?>">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="fg_deadline"><?php esc_html_e( 'Deadline', 'f-grants' ); ?></label></th>
                        <td>
                            <input type="text" name="fg_deadline" id="fg_deadline" class="regular-text" value="<?php echo esc_attr( $opp['deadline'] ?? '' ); ?>" placeholder="e.g. March 15, 2026">
                        </td>
                    </tr>
                    <tr>
                        <th><label for="fg_raw_input"><?php esc_html_e( 'Funder Material', 'f-grants' ); ?></label></th>
                        <td>
                            <textarea name="fg_raw_input" id="fg_raw_input" rows="12" class="large-text"><?php echo esc_textarea( $opp['raw_input'] ?? '' ); ?></textarea>
                            <p class="description"><?php esc_html_e( 'Paste the funder\'s RFP, guidelines, or eligibility criteria. Claude will extract and structure what matters.', 'f-grants' ); ?></p>
                        </td>
                    </tr>
                </table>

                <p class="fg-extract-actions">
                    <?php submit_button( $is_edit ? __( 'Update Opportunity', 'f-grants' ) : __( 'Save Opportunity', 'f-grants' ), 'primary', 'fg_save_opportunity', false ); ?>
                    &nbsp;
                    <?php if ( $is_edit ) : ?>
                    <button type="button" id="fg-extract-criteria" class="button" data-opp-id="<?php echo esc_attr( $opp_id ); ?>">
                        <?php esc_html_e( 'Extract Criteria with Claude', 'f-grants' ); ?>
                    </button>
                    <?php endif; ?>
                </p>
            </form>

            <?php if ( ! empty( $criteria ) ) : ?>
            <hr>
            <div class="fg-criteria-display">
                <h2><?php esc_html_e( 'Extracted Criteria', 'f-grants' ); ?></h2>
                <div class="fg-criteria-grid">
                    <?php if ( ! empty( $criteria['eligibility'] ) ) : ?>
                    <div class="fg-criteria-block">
                        <h3><?php esc_html_e( 'Eligibility', 'f-grants' ); ?></h3>
                        <ul><?php foreach ( (array) $criteria['eligibility'] as $item ) echo '<li>' . esc_html( $item ) . '</li>'; ?></ul>
                    </div>
                    <?php endif; ?>
                    <?php if ( ! empty( $criteria['priorities'] ) ) : ?>
                    <div class="fg-criteria-block">
                        <h3><?php esc_html_e( 'Priorities', 'f-grants' ); ?></h3>
                        <ul><?php foreach ( (array) $criteria['priorities'] as $item ) echo '<li>' . esc_html( $item ) . '</li>'; ?></ul>
                    </div>
                    <?php endif; ?>
                    <?php if ( ! empty( $criteria['values_language'] ) ) : ?>
                    <div class="fg-criteria-block">
                        <h3><?php esc_html_e( 'Values Language', 'f-grants' ); ?></h3>
                        <ul><?php foreach ( (array) $criteria['values_language'] as $item ) echo '<li>' . esc_html( $item ) . '</li>'; ?></ul>
                    </div>
                    <?php endif; ?>
                    <?php if ( ! empty( $criteria['tone'] ) ) : ?>
                    <div class="fg-criteria-block">
                        <h3><?php esc_html_e( 'Tone', 'f-grants' ); ?></h3>
                        <p><?php echo esc_html( $criteria['tone'] ); ?></p>
                    </div>
                    <?php endif; ?>
                    <?php if ( ! empty( $criteria['implicit_signals'] ) ) : ?>
                    <div class="fg-criteria-block">
                        <h3><?php esc_html_e( 'Implicit Signals', 'f-grants' ); ?></h3>
                        <ul><?php foreach ( (array) $criteria['implicit_signals'] as $item ) echo '<li>' . esc_html( $item ) . '</li>'; ?></ul>
                    </div>
                    <?php endif; ?>
                    <?php if ( ! empty( $criteria['red_flags'] ) ) : ?>
                    <div class="fg-criteria-block fg-criteria-block--warning">
                        <h3><?php esc_html_e( 'Red Flags', 'f-grants' ); ?></h3>
                        <ul><?php foreach ( (array) $criteria['red_flags'] as $item ) echo '<li>' . esc_html( $item ) . '</li>'; ?></ul>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function save_opportunity(): void {
        $opp_id = isset( $_POST['fg_opp_id'] ) ? absint( $_POST['fg_opp_id'] ) : 0;

        $data = array(
            'title'       => sanitize_text_field( $_POST['fg_opp_title'] ?? '' ),
            'funder_name' => sanitize_text_field( $_POST['fg_funder_name'] ?? '' ),
            'deadline'    => sanitize_text_field( $_POST['fg_deadline'] ?? '' ),
            'raw_input'   => wp_kses_post( $_POST['fg_raw_input'] ?? '' ),
        );

        if ( $opp_id ) {
            // Update title
            wp_update_post( array( 'ID' => $opp_id, 'post_title' => $data['title'] ) );
            update_post_meta( $opp_id, '_fg_funder_name', $data['funder_name'] );
            update_post_meta( $opp_id, '_fg_raw_input',   $data['raw_input'] );
            update_post_meta( $opp_id, '_fg_deadline',    $data['deadline'] );
            wp_redirect( admin_url( 'admin.php?page=f-grants-opportunities&action=edit&opp_id=' . $opp_id . '&saved=1' ) );
        } else {
            $new_id = FG_Opportunity::insert( $data );
            if ( is_wp_error( $new_id ) ) {
                wp_redirect( admin_url( 'admin.php?page=f-grants-opportunities&action=new&error=1' ) );
            } else {
                wp_redirect( admin_url( 'admin.php?page=f-grants-opportunities&action=edit&opp_id=' . $new_id . '&saved=1' ) );
            }
        }
        exit;
    }

    // -------------------------------------------------------------------------
    // Applications
    // -------------------------------------------------------------------------

    public static function render_applications_page(): void {
        $action = isset( $_GET['action'] ) ? sanitize_text_field( $_GET['action'] ) : 'list';
        $app_id = isset( $_GET['app_id'] ) ? absint( $_GET['app_id'] ) : 0;

        if ( $action === 'new' ) {
            self::render_application_form();
            return;
        }
        if ( $action === 'view' && $app_id ) {
            self::render_application_view( $app_id );
            return;
        }

        $applications = FG_Application::get_all();
        $statuses     = FG_Application::get_statuses();
        ?>
        <div class="wrap fg-wrap">
            <h1><?php esc_html_e( 'Applications', 'f-grants' ); ?></h1>

            <?php if ( isset( $_GET['deleted'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Application deleted.', 'f-grants' ); ?></p></div>
            <?php endif; ?>

            <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-applications&action=new' ) ); ?>" class="page-title-action"><?php esc_html_e( 'New Application', 'f-grants' ); ?></a>

            <?php if ( empty( $applications ) ) : ?>
            <p><?php esc_html_e( 'No applications yet. Select a Profile and Opportunity to generate your first Bridge.', 'f-grants' ); ?></p>
            <?php else : ?>
            <table class="widefat striped fg-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Application', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Draft', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Date', 'f-grants' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'f-grants' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $applications as $app ) : ?>
                    <tr>
                        <td><strong><?php echo esc_html( $app['title'] ); ?></strong></td>
                        <td><span class="fg-status fg-status--<?php echo esc_attr( $app['status'] ); ?>"><?php echo esc_html( $statuses[ $app['status'] ] ?? $app['status'] ); ?></span></td>
                        <td><?php echo empty( $app['draft_output'] ) ? '—' : '<span class="fg-badge fg-badge--yes">' . esc_html__( 'Ready', 'f-grants' ) . '</span>'; ?></td>
                        <td><?php echo esc_html( date_i18n( get_option( 'date_format' ), strtotime( $app['date'] ) ) ); ?></td>
                        <td>
                            <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-applications&action=view&app_id=' . $app['ID'] ) ); ?>"><?php esc_html_e( 'View', 'f-grants' ); ?></a>
                            &nbsp;|&nbsp;
                            <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=f-grants-applications&action=delete_application&app_id=' . $app['ID'] ), 'fg_delete_app_' . $app['ID'] ) ); ?>"
                               onclick="return confirm('<?php esc_attr_e( 'Delete this application?', 'f-grants' ); ?>')"
                               class="fg-delete-link"><?php esc_html_e( 'Delete', 'f-grants' ); ?></a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function render_application_form(): void {
        $profiles      = FG_Profile::get_all();
        $opportunities = FG_Opportunity::get_all();
        ?>
        <div class="wrap fg-wrap">
            <h1><?php esc_html_e( 'New Application', 'f-grants' ); ?></h1>
            <p><?php esc_html_e( 'Select a profile and opportunity. Claude will generate the Bridge draft on the next screen.', 'f-grants' ); ?></p>

            <?php if ( empty( $profiles ) ) : ?>
            <div class="notice notice-warning inline"><p><?php printf( esc_html__( 'You need at least one profile. %s', 'f-grants' ), '<a href="' . esc_url( admin_url( 'admin.php?page=f-grants-profiles&action=new' ) ) . '">' . esc_html__( 'Create a profile →', 'f-grants' ) . '</a>' ); ?></p></div>
            <?php elseif ( empty( $opportunities ) ) : ?>
            <div class="notice notice-warning inline"><p><?php printf( esc_html__( 'You need at least one opportunity. %s', 'f-grants' ), '<a href="' . esc_url( admin_url( 'admin.php?page=f-grants-opportunities&action=new' ) ) . '">' . esc_html__( 'Add an opportunity →', 'f-grants' ) . '</a>' ); ?></p></div>
            <?php else : ?>
            <form method="post" action="">
                <?php wp_nonce_field( 'fg_application_nonce' ); ?>
                <input type="hidden" name="fg_save_application" value="1">

                <table class="form-table fg-form-table">
                    <tr>
                        <th><label for="fg_app_profile_id"><?php esc_html_e( 'Applicant Profile', 'f-grants' ); ?></label></th>
                        <td>
                            <select name="fg_app_profile_id" id="fg_app_profile_id" required>
                                <option value=""><?php esc_html_e( '— Select a profile —', 'f-grants' ); ?></option>
                                <?php foreach ( $profiles as $p ) : ?>
                                <option value="<?php echo esc_attr( $p['id'] ); ?>"><?php echo esc_html( $p['entity_name'] ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="fg_app_opp_id"><?php esc_html_e( 'Opportunity', 'f-grants' ); ?></label></th>
                        <td>
                            <select name="fg_app_opp_id" id="fg_app_opp_id" required>
                                <option value=""><?php esc_html_e( '— Select an opportunity —', 'f-grants' ); ?></option>
                                <?php foreach ( $opportunities as $o ) : ?>
                                <option value="<?php echo esc_attr( $o['ID'] ); ?>"><?php echo esc_html( $o['title'] . ( $o['funder_name'] ? ' (' . $o['funder_name'] . ')' : '' ) ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="fg_advocacy_context"><?php esc_html_e( 'Advocacy Context', 'f-grants' ); ?></label></th>
                        <td>
                            <textarea name="fg_advocacy_context" id="fg_advocacy_context" rows="5" class="large-text" placeholder="<?php esc_attr_e( 'Optional. What external conditions (political, economic, social) are affecting this org\'s or artist\'s ability to deliver right now? This is where the honest positioning lives.', 'f-grants' ); ?>"></textarea>
                        </td>
                    </tr>
                </table>

                <?php submit_button( __( 'Create Application', 'f-grants' ) ); ?>
            </form>
            <?php endif; ?>
        </div>
        <?php
    }

    private static function render_application_view( int $app_id ): void {
        $app         = FG_Application::get( $app_id );
        $profile     = $app ? FG_Profile::get( $app['profile_id'] ) : null;
        $opportunity = $app ? FG_Opportunity::get( $app['opportunity_id'] ) : null;
        $statuses    = FG_Application::get_statuses();

        if ( ! $app ) {
            echo '<div class="wrap"><p>' . esc_html__( 'Application not found.', 'f-grants' ) . '</p></div>';
            return;
        }

        $outcome_log = FG_Outcome::get_log( $app_id );
        ?>
        <div class="wrap fg-wrap">
            <h1><?php echo esc_html( $app['title'] ); ?></h1>
            <p>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-applications' ) ); ?>">&larr; <?php esc_html_e( 'All Applications', 'f-grants' ); ?></a>
                &nbsp;&nbsp;
                <span class="fg-status fg-status--<?php echo esc_attr( $app['status'] ); ?>"><?php echo esc_html( $statuses[ $app['status'] ] ?? $app['status'] ); ?></span>
            </p>

            <?php if ( isset( $_GET['saved'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Saved.', 'f-grants' ); ?></p></div>
            <?php endif; ?>

            <!-- Bridge Draft -->
            <div class="fg-bridge-section">
                <h2><?php esc_html_e( 'The Bridge', 'f-grants' ); ?></h2>

                <?php if ( empty( $app['draft_output'] ) ) : ?>
                <p><?php esc_html_e( 'No draft generated yet.', 'f-grants' ); ?></p>
                <button type="button" id="fg-generate-bridge" class="button button-primary"
                    data-app-id="<?php echo esc_attr( $app_id ); ?>">
                    <?php esc_html_e( 'Generate Bridge with Claude', 'f-grants' ); ?>
                </button>
                <div id="fg-bridge-output" class="fg-bridge-output" style="display:none;"></div>
                <?php else : ?>
                <div id="fg-bridge-output" class="fg-bridge-output">
                    <?php echo wp_kses_post( wpautop( $app['draft_output'] ) ); ?>
                </div>
                <p class="fg-bridge-meta"><?php esc_html_e( 'Working draft — review and edit before submitting.', 'f-grants' ); ?></p>
                <button type="button" id="fg-generate-bridge" class="button"
                    data-app-id="<?php echo esc_attr( $app_id ); ?>">
                    <?php esc_html_e( 'Regenerate Bridge', 'f-grants' ); ?>
                </button>
                <?php endif; ?>
            </div>

            <hr>

            <!-- Update Status -->
            <div class="fg-status-section">
                <h2><?php esc_html_e( 'Update Status', 'f-grants' ); ?></h2>
                <form method="post" action="">
                    <?php wp_nonce_field( 'fg_status_nonce' ); ?>
                    <input type="hidden" name="fg_update_status" value="1">
                    <input type="hidden" name="fg_app_id" value="<?php echo esc_attr( $app_id ); ?>">

                    <table class="form-table fg-form-table">
                        <tr>
                            <th><label for="fg_status"><?php esc_html_e( 'Status', 'f-grants' ); ?></label></th>
                            <td>
                                <select name="fg_status" id="fg_status">
                                    <?php foreach ( $statuses as $val => $label ) : ?>
                                    <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $app['status'], $val ); ?>><?php echo esc_html( $label ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                        </tr>
                        <tr>
                            <th><label for="fg_notes"><?php esc_html_e( 'Notes', 'f-grants' ); ?></label></th>
                            <td>
                                <textarea name="fg_notes" id="fg_notes" rows="4" class="large-text"><?php echo esc_textarea( $app['notes'] ); ?></textarea>
                                <p class="description"><?php esc_html_e( 'What happened? What feedback did you get? This feeds the profile sharpening loop.', 'f-grants' ); ?></p>
                            </td>
                        </tr>
                    </table>

                    <?php submit_button( __( 'Update Status', 'f-grants' ) ); ?>
                </form>
            </div>

            <?php if ( ! empty( $outcome_log ) ) : ?>
            <hr>
            <div class="fg-outcome-log">
                <h2><?php esc_html_e( 'Outcome Log', 'f-grants' ); ?></h2>
                <table class="widefat striped fg-table">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Date', 'f-grants' ); ?></th>
                            <th><?php esc_html_e( 'Outcome', 'f-grants' ); ?></th>
                            <th><?php esc_html_e( 'Notes', 'f-grants' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( array_reverse( $outcome_log ) as $entry ) : ?>
                        <tr>
                            <td><?php echo esc_html( $entry['date'] ); ?></td>
                            <td><span class="fg-status fg-status--<?php echo esc_attr( $entry['outcome'] ); ?>"><?php echo esc_html( $statuses[ $entry['outcome'] ] ?? $entry['outcome'] ); ?></span></td>
                            <td><?php echo esc_html( $entry['writer_notes'] ); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

            <!-- Profile Snapshot -->
            <hr>
            <details class="fg-snapshot">
                <summary><?php esc_html_e( 'Profile Snapshot (at time of application)', 'f-grants' ); ?></summary>
                <pre><?php echo esc_html( wp_json_encode( $app['profile_snapshot'], JSON_PRETTY_PRINT ) ); ?></pre>
            </details>

        </div>
        <?php
    }

    private static function save_application(): void {
        $data = array(
            'profile_id'       => absint( $_POST['fg_app_profile_id'] ?? 0 ),
            'opportunity_id'   => absint( $_POST['fg_app_opp_id'] ?? 0 ),
            'advocacy_context' => wp_kses_post( $_POST['fg_advocacy_context'] ?? '' ),
        );

        $new_id = FG_Application::insert( $data );

        if ( is_wp_error( $new_id ) ) {
            wp_redirect( admin_url( 'admin.php?page=f-grants-applications&action=new&error=1' ) );
        } else {
            wp_redirect( admin_url( 'admin.php?page=f-grants-applications&action=view&app_id=' . $new_id ) );
        }
        exit;
    }

    private static function update_application_status(): void {
        $app_id = absint( $_POST['fg_app_id'] ?? 0 );
        $status = sanitize_text_field( $_POST['fg_status'] ?? '' );
        $notes  = sanitize_textarea_field( $_POST['fg_notes'] ?? '' );

        FG_Application::update_status( $app_id, $status, $notes );
        wp_redirect( admin_url( 'admin.php?page=f-grants-applications&action=view&app_id=' . $app_id . '&saved=1' ) );
        exit;
    }

    // -------------------------------------------------------------------------
    // Settings
    // -------------------------------------------------------------------------

    public static function render_settings_page(): void {
        $valid_tabs  = array( 'api', 'debug' );
        $default_tab = FG_Crypto::get_key( FG_Crypto::CLAUDE_KEY_OPTION ) ? 'debug' : 'api';
        $active_tab  = isset( $_GET['tab'] ) && in_array( $_GET['tab'], $valid_tabs, true )
            ? sanitize_key( $_GET['tab'] )
            : $default_tab;

        $claude_api_key  = FG_Crypto::get_key( FG_Crypto::CLAUDE_KEY_OPTION );
        $claude_model    = get_option( 'fg_claude_model', FG_Claude::MODEL );
        $debug_enabled   = get_option( 'fg_debug_log_enabled', '0' );
        $log_file        = FG_Logger::get_log_file();
        ?>
        <div class="wrap fg-wrap">
            <h1><?php esc_html_e( 'F! Grants Settings', 'f-grants' ); ?></h1>

            <?php if ( isset( $_GET['saved'] ) ) : ?>
            <div class="notice notice-success is-dismissible"><p><?php esc_html_e( 'Settings saved.', 'f-grants' ); ?></p></div>
            <?php endif; ?>

            <nav class="nav-tab-wrapper">
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-settings&tab=api' ) ); ?>"
                   class="nav-tab <?php echo $active_tab === 'api' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e( 'API', 'f-grants' ); ?>
                </a>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=f-grants-settings&tab=debug' ) ); ?>"
                   class="nav-tab <?php echo $active_tab === 'debug' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e( 'Debug', 'f-grants' ); ?>
                </a>
            </nav>

            <form method="post" action="">
                <?php wp_nonce_field( 'fg_settings_nonce' ); ?>
                <input type="hidden" name="fg_save_settings" value="1">
                <input type="hidden" name="fg_active_tab" value="<?php echo esc_attr( $active_tab ); ?>">

                <?php if ( $active_tab === 'api' ) : ?>
                <table class="form-table fg-form-table">
                    <tr>
                        <th><label for="fg_claude_api_key"><?php esc_html_e( 'Claude API Key', 'f-grants' ); ?></label></th>
                        <td>
                            <input type="password" name="fg_claude_api_key" id="fg_claude_api_key" class="regular-text"
                                   value="<?php echo esc_attr( $claude_api_key ? str_repeat( '•', 20 ) : '' ); ?>"
                                   placeholder="<?php esc_attr_e( 'sk-ant-...', 'f-grants' ); ?>"
                                   autocomplete="new-password">
                            <p class="description">
                                <?php if ( $claude_api_key ) : ?>
                                <span class="fg-key-saved"><?php esc_html_e( '✓ Key saved and encrypted.', 'f-grants' ); ?></span>
                                <?php else : ?>
                                <?php esc_html_e( 'Required. Get your key at console.anthropic.com', 'f-grants' ); ?>
                                <?php endif; ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th><label for="fg_claude_model"><?php esc_html_e( 'Claude Model', 'f-grants' ); ?></label></th>
                        <td>
                            <select name="fg_claude_model" id="fg_claude_model">
                                <option value="claude-sonnet-4-6" <?php selected( $claude_model, 'claude-sonnet-4-6' ); ?>>claude-sonnet-4-6 (recommended)</option>
                                <option value="claude-opus-4-6" <?php selected( $claude_model, 'claude-opus-4-6' ); ?>>claude-opus-4-6 (higher quality, slower)</option>
                                <option value="claude-haiku-4-5-20251001" <?php selected( $claude_model, 'claude-haiku-4-5-20251001' ); ?>>claude-haiku-4-5 (faster, lower cost)</option>
                            </select>
                        </td>
                    </tr>
                </table>

                <?php elseif ( $active_tab === 'debug' ) : ?>
                <table class="form-table fg-form-table">
                    <tr>
                        <th><label for="fg_debug_log_enabled"><?php esc_html_e( 'Debug Logging', 'f-grants' ); ?></label></th>
                        <td>
                            <label>
                                <input type="checkbox" name="fg_debug_log_enabled" id="fg_debug_log_enabled" value="1" <?php checked( $debug_enabled, '1' ); ?>>
                                <?php esc_html_e( 'Enable debug log', 'f-grants' ); ?>
                            </label>
                            <p class="description"><?php esc_html_e( 'Logs warnings and Claude API calls to wp-content/fg-debug.log', 'f-grants' ); ?></p>
                        </td>
                    </tr>
                </table>

                <?php if ( file_exists( $log_file ) ) : ?>
                <p>
                    <a href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin.php?page=f-grants-settings&tab=debug&action=clear_log' ), 'fg_clear_log' ) ); ?>" class="button">
                        <?php esc_html_e( 'Clear Log', 'f-grants' ); ?>
                    </a>
                </p>
                <textarea class="large-text fg-log-textarea" rows="20" readonly><?php echo esc_textarea( file_get_contents( $log_file ) ); ?></textarea>
                <?php endif; ?>
                <?php endif; ?>

                <?php submit_button( __( 'Save Settings', 'f-grants' ) ); ?>
            </form>
        </div>
        <?php
    }

    private static function save_settings(): void {
        $active_tab = sanitize_key( $_POST['fg_active_tab'] ?? 'api' );

        if ( $active_tab === 'api' ) {
            $key_input = trim( $_POST['fg_claude_api_key'] ?? '' );
            // Only update if it's not the masked placeholder
            if ( $key_input && strpos( $key_input, '•' ) === false ) {
                FG_Crypto::save_key( FG_Crypto::CLAUDE_KEY_OPTION, $key_input );
            }
            update_option( 'fg_claude_model', sanitize_text_field( $_POST['fg_claude_model'] ?? FG_Claude::MODEL ) );
        }

        if ( $active_tab === 'debug' ) {
            update_option( 'fg_debug_log_enabled', isset( $_POST['fg_debug_log_enabled'] ) ? '1' : '0' );
        }
    }
}
