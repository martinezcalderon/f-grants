<?php
/**
 * Fired during plugin deactivation.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Deactivator {

    public static function deactivate(): void {
        $timestamp = wp_next_scheduled( 'fg_sharpen_profiles' );
        if ( $timestamp ) {
            wp_unschedule_event( $timestamp, 'fg_sharpen_profiles' );
        }

        flush_rewrite_rules();
    }
}
