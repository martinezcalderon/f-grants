<?php
/**
 * AJAX handlers for F! Grants.
 *
 * Handles:
 *  - Bridge generation (generate_bridge)
 *  - Criteria extraction (extract_criteria)
 *  - Practice dialogue (practice_dialogue) — artist segment only
 *  - Profile sharpening trigger (sharpen_profile)
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class FG_Ajax {

    public function __construct() {
        add_action( 'wp_ajax_fg_generate_bridge',    array( $this, 'generate_bridge' ) );
        add_action( 'wp_ajax_fg_extract_criteria',   array( $this, 'extract_criteria' ) );
        add_action( 'wp_ajax_fg_practice_dialogue',  array( $this, 'practice_dialogue' ) );
        add_action( 'wp_ajax_fg_sharpen_profile',    array( $this, 'sharpen_profile' ) );
    }

    // -------------------------------------------------------------------------
    // Bridge Generation
    // -------------------------------------------------------------------------

    public function generate_bridge(): void {
        check_ajax_referer( 'fg_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'f-grants' ) ), 403 );
        }

        $app_id = absint( $_POST['app_id'] ?? 0 );
        $app    = FG_Application::get( $app_id );

        if ( ! $app ) {
            wp_send_json_error( array( 'message' => __( 'Application not found.', 'f-grants' ) ) );
        }

        $profile     = FG_Profile::get( $app['profile_id'] );
        $opportunity = FG_Opportunity::get( $app['opportunity_id'] );

        if ( ! $profile || ! $opportunity ) {
            wp_send_json_error( array( 'message' => __( 'Profile or Opportunity not found.', 'f-grants' ) ) );
        }

        $criteria = $opportunity['extracted_criteria'];
        if ( empty( $criteria ) ) {
            // Auto-extract if not done yet
            $extracted = FG_Claude::extract_criteria( $opportunity['raw_input'] );
            if ( ! is_wp_error( $extracted ) ) {
                FG_Opportunity::save_criteria( $opportunity['ID'], $extracted );
                $criteria = $extracted;
            }
        }

        $result = FG_Claude::generate_bridge(
            $profile,
            $criteria,
            $app['advocacy_context'] ?? ''
        );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        FG_Application::save_draft( $app_id, $result );

        wp_send_json_success( array(
            'draft' => $result,
            'draft_html' => wpautop( esc_html( $result ) ),
        ) );
    }

    // -------------------------------------------------------------------------
    // Criteria Extraction
    // -------------------------------------------------------------------------

    public function extract_criteria(): void {
        check_ajax_referer( 'fg_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'f-grants' ) ), 403 );
        }

        $opp_id = absint( $_POST['opp_id'] ?? 0 );
        $opp    = FG_Opportunity::get( $opp_id );

        if ( ! $opp ) {
            wp_send_json_error( array( 'message' => __( 'Opportunity not found.', 'f-grants' ) ) );
        }

        if ( empty( $opp['raw_input'] ) ) {
            wp_send_json_error( array( 'message' => __( 'No funder material to extract from. Add some text first.', 'f-grants' ) ) );
        }

        $result = FG_Claude::extract_criteria( $opp['raw_input'] );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        FG_Opportunity::save_criteria( $opp_id, $result );

        wp_send_json_success( array(
            'criteria' => $result,
            'message'  => __( 'Criteria extracted and saved. Reload the page to see them.', 'f-grants' ),
        ) );
    }

    // -------------------------------------------------------------------------
    // Practice Dialogue (artist only)
    // -------------------------------------------------------------------------

    public function practice_dialogue(): void {
        check_ajax_referer( 'fg_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'f-grants' ) ), 403 );
        }

        $profile_id = absint( $_POST['profile_id'] ?? 0 );
        $message    = sanitize_textarea_field( $_POST['message'] ?? '' );
        $history_raw = $_POST['history'] ?? '[]';
        $history    = json_decode( wp_unslash( $history_raw ), true );

        if ( ! is_array( $history ) ) {
            $history = array();
        }

        $profile = FG_Profile::get( $profile_id );

        if ( ! $profile ) {
            wp_send_json_error( array( 'message' => __( 'Profile not found.', 'f-grants' ) ) );
        }

        if ( $profile['segment'] !== FG_Profile::SEGMENT_ARTIST ) {
            wp_send_json_error( array( 'message' => __( 'Practice dialogue is for artist profiles only.', 'f-grants' ) ) );
        }

        $result = FG_Claude::practice_dialogue( $profile, $message, $history );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array( 'response' => $result ) );
    }

    // -------------------------------------------------------------------------
    // Manual Profile Sharpening
    // -------------------------------------------------------------------------

    public function sharpen_profile(): void {
        check_ajax_referer( 'fg_admin_nonce', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( array( 'message' => __( 'Unauthorized.', 'f-grants' ) ), 403 );
        }

        $profile_id = absint( $_POST['profile_id'] ?? 0 );
        $result     = FG_Claude::sharpen_profile( $profile_id );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        // Ask admin to confirm before saving to profile history
        wp_send_json_success( array(
            'suggestion' => $result,
            'message'    => __( 'Review the suggestion below. Save it to the profile history when ready.', 'f-grants' ),
        ) );
    }
}
