<?php
/**
 * Fired when the plugin is uninstalled (deleted, not deactivated).
 *
 * Removes all F! Grants data: custom tables, post types, options.
 * This is irreversible — data is gone.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

global $wpdb;

// Drop custom tables
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}fg_profiles" );

// Delete all CPT posts
$post_types = array( 'fg_opportunity', 'fg_application' );
foreach ( $post_types as $post_type ) {
    $posts = get_posts( array(
        'post_type'      => $post_type,
        'post_status'    => 'any',
        'posts_per_page' => -1,
        'fields'         => 'ids',
    ) );
    foreach ( $posts as $post_id ) {
        wp_delete_post( $post_id, true );
    }
}

// Delete all options
$options = array(
    'fg_claude_api_key',
    'fg_claude_model',
    'fg_debug_log_enabled',
    'fg_profile_limit',
);
foreach ( $options as $option ) {
    delete_option( $option );
}

// Remove debug log
$log_file = WP_CONTENT_DIR . '/fg-debug.log';
if ( file_exists( $log_file ) ) {
    // phpcs:ignore WordPress.WP.AlternativeFunctions.unlink_unlink
    unlink( $log_file );
}

// Clear cron events
wp_clear_scheduled_hook( 'fg_sharpen_profiles' );
